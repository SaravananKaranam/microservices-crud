package com.example.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServiceInterApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiceInterApplication.class, args);
	}

}

